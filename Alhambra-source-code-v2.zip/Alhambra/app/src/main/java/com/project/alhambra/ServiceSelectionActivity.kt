package com.capstone.alhambra

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.capstone.alhambra.databinding.ActivityServiceSelectionBinding
import java.text.SimpleDateFormat
import java.util.Date

class ServiceSelectionActivity : AppCompatActivity() {
    lateinit var binding: ActivityServiceSelectionBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityServiceSelectionBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding.cvOption1.setOnClickListener {
            nextActivity()
        }
        binding.cvOption2.setOnClickListener {
            nextActivity()
        }
        binding.cvOption3.setOnClickListener {
            nextActivity()
        }
        binding.cvOption4.setOnClickListener {
            nextActivity()
        }
        binding.cvOption5.setOnClickListener {
            nextActivity()
        }
        binding.cvOption6.setOnClickListener {
            nextActivity()
        }
        binding.cvOption7.setOnClickListener {
            nextActivity()
        }
        binding.cvOption8.setOnClickListener {
            nextActivity()
        }


    }

    private fun nextActivity() {
        startActivity(Intent(this, ResultActivity::class.java))
    }

}