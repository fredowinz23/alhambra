package com.capstone.alhambra

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.capstone.alhambra.databinding.ActivityCalendarBinding
import java.text.SimpleDateFormat
import java.util.Date

class CalendarActivity : AppCompatActivity() {
    lateinit var binding: ActivityCalendarBinding
    @SuppressLint("SimpleDateFormat")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityCalendarBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)


        binding.llSelectTime.visibility = View.GONE
        binding.cvCalendar.setOnDateChangeListener { _, year, month, dayOfMonth ->
            binding.llSelectTime.visibility = View.VISIBLE
            val sdf = SimpleDateFormat("yyyy-MM-dd")
            val selectedDates: String = sdf.format(Date(year - 1900, month, dayOfMonth))
            binding.tvDate.text = selectedDates
        }

        binding.cvOption1.setOnClickListener {
            nextActivity()
        }

        binding.cvOption2.setOnClickListener {
            nextActivity()
        }

        binding.cvOption3.setOnClickListener {
            nextActivity()
        }

        binding.cvOption4.setOnClickListener {
            nextActivity()
        }

        binding.cvOption5.setOnClickListener {
            nextActivity()
        }

        binding.cvOption6.setOnClickListener {
            nextActivity()
        }

        binding.cvOption7.setOnClickListener {
            nextActivity()
        }

        binding.cvOption8.setOnClickListener {
            nextActivity()
        }

    }

    private fun nextActivity() {
        startActivity(Intent(this, ServiceSelectionActivity::class.java))
    }
}